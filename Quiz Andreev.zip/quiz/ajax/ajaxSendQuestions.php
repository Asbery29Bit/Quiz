<?php 
     //Логика добавления ответов в бд
     if ( isset( $_POST[ 'data' ] ) && $_POST[ 'data' ] != '' ){
          define("INDEX", "");
          $data = $_POST[ 'data' ];
          //$data[ 'date_end' ] = date('y-m-d h:i:s');
          include_once "../module/User.php";
          include_once "../module/Question.php";
          $user = new User();
          $question = new Question();
          $results = $question->SaveResults( $data );
          //print_r( $data );
     }
?>