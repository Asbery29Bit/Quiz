<?php 
     //Логика добавления user в бд
     if ( isset( $_POST[ 'data' ] ) && $_POST[ 'data' ] != '' ){
          define("INDEX", "");
          $data = json_decode( $_POST[ 'data' ], true );
          $data_check = json_decode( $_POST[ 'data' ], true );
          $data[ 'date_start' ] = date('y-m-d h:i:s');
          include_once "../module/User.php";
          $user = new User();
          $results_check = $user->checkUser( $data_check );
          if ( !empty( $results_check ) && $results_check != '' ){
               $back_res = [
                    'value' => 'not complete'
               ];
               echo json_encode( $back_res );
          }else{
               $back_res = [
                    'value' => 'complete'
               ];
               $results = $user->createUser( $data );
               if (session_status() == PHP_SESSION_ACTIVE) {
                    session_destroy();
               }
               session_start();
               $_SESSION['name_auth'] = $data[ 'name' ];
               echo json_encode( $back_res );
          }
     }
?>