<?php 
     //Логика получения вопросов и ответов
     header('Content-Type: application/json');
          define("INDEX", "");
          include_once "../module/Question.php";

          $questions = new Question();
          $data = $questions->GetData();
          $random_data = $questions->randomData( $data );
          echo json_encode( $random_data );
?>