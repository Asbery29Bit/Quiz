<?php 
defined('INDEX') OR die('Прямой доступ к странице запрещён!');
include_once "module/Database.php";
include_once "module/Router.php";
$conn = new Database;
$router = new Router;
$path = $router->run();
?>