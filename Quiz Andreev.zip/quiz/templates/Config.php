<?php
defined('INDEX') OR die('Прямой доступ к странице запрещён!');
return [
     ''    => '/templates/path/main.php',
     'login'    => '/templates/path/login.php',
     'question'  => '/templates/path/question.php',
     'graph'  => '/templates/path/graph.php'
];
?>