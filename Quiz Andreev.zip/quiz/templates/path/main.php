    <main>
      <section>
      <div class="container">
  <div class="left">
    <div class="main">
      <h2 class="animation a1">Minecraft Quiz</h2>
          <h4 class="animation a2">Квиз по Майнкрафту</h4>
    </div>
    <div class="form">
      <input id="name_user" type="text" class="form-field animation a3" placeholder="Name">
      <br>
      <button id="button_main" class="animation a6">Начать</button>
    </div>
  </div>
  <div class="right"></div>
</div>

      </section>
    </main>
