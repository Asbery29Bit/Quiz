<script src="/assets/js/question.js" ></script>
<div class="quest-conteiner">
     <div class="quest-form">
          <div class="quest">
               <h2 id="quest_name" ></h2>
          </div>
          <div class="answers">
               <ul id = "quest_list">
               </ul>
          </div>
          <div id = "button_send" class="button_send">
          <button id="buton_quest" class="next_quest"> Следующий вопрос</button>
          </div>
     </div>
</div>