<?php
include_once "./module/Graph.php";
$graph = new Graph();
$data = $graph->GetData();
$sumofelements = array_sum($data);
foreach ( $data as $id => $count ){
    if ( $count != 0 ){
        $procent_result = $count/$sumofelements *100;
        $data[ $id ] = round( $procent_result );
    }
}
?>
<link rel="stylesheet" href="./assets/css/graph.css">
<main>
  <section>
    <h2>Гистограмма</h2>
<div class="conteiner">
<div class="simple-bar-chart" style="height:70vh; margin-left: 40%; margin-top:2%">
  <div class="item" style="--clr: #5EB344; --val: <?php echo $data[0]?>">
    <div class="label">0</div>
    <div class="value"><?php echo $data[0]?>%</div>
  </div>
  <div class="item" style="--clr: #5EB344; --val: <?php echo $data[1]?>">
    <div class="label">1</div>
    <div class="value"><?php echo $data[1]?>%</div>
  </div>
  
  <div class="item" style="--clr: #FCB72A; --val: <?php echo $data[2]?>">
    <div class="label">2</div>
    <div class="value"><?php echo $data[2]?>%</div>
  </div>
  
  <div class="item" style="--clr: #F8821A; --val: <?php echo $data[3]?>">
    <div class="label">3</div>
    <div class="value"><?php echo $data[3]?>%</div>
  </div>
  
  <div class="item" style="--clr: #E0393E; --val: <?php echo $data[4]?>">
    <div class="label">4</div>
    <div class="value"><?php echo $data[4]?>%</div>
  </div>
  
  <div class="item" style="--clr: #963D97; --val: <?php echo $data[5]?>">
    <div class="label">5</div>
    <div class="value"><?php echo $data[5]?>%</div>
  </div>
  
  </div>
  </section>
  <button id="back_button" class="back_quest"> Вернуться на главную</button>
</main>