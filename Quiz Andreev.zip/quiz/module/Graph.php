<?php
defined('INDEX') OR die('Прямой доступ к странице запрещён!');
include_once "Database.php";
class Graph {
     private $database;
     public function __construct()
     {
         $this->database = new Database;
     }
     public function GetData() {
          $massive = [
               '0'  => 0,
               '1'  => 0,
               '2'  => 0,
               '3'  => 0,
               '4'  => 0,
               '5'  => 0
          ];
          $sql = "select id, correct_answers from results";
          $data = $this->database->SQL( $sql );
          $result = [];
          foreach ( $data as $info ){
               if ( isset($info[ 'correct_answers']) && $info[ 'correct_answers'] != '' ){
                    $massive[ $info[ 'correct_answers'] ]++;
               } 
          }
          return $massive;
     }

}

?>