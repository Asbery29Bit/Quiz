<?php
defined('INDEX') OR die('Прямой доступ к странице запрещён!');
include_once "Database.php";
class Question {
     private $database;
     public function __construct()
     {
         $this->database = new Database;
     }
     public function GetData() {
          $result[ 'questions' ] = $this->database->SQL( "select * from questions" );
          $result[ 'answers' ] = $this->database->SQL( "select * from answers" );
          foreach ( $result[ 'questions'] as $value ){
               $massive[ $value[ 'id' ] ][ 'quest' ] = $value[ 'name' ]; 
          }
          foreach ( $result[ 'answers' ] as $value ){
               $massive[ $value[ 'id_question' ] ][ 'answ' ][] = [ 
                    'name'    => $value[ 'id_name' ],
                    'right'    => $value[ 'right_answer' ]  
               ]; 
          }
          return $massive;
     }
     public function randomData ( $data ){
          $massive = [];
          $random_ids =  array_rand($data, 5);
          foreach ( $random_ids as $id ) {
               $random_questions[] = $data[ $id ];
          } 
          foreach ( $random_questions as $numb => $quest ){
               $massive[ $numb ][ 'name' ] = $quest[ 'quest' ];
               foreach ( $quest[ 'answ' ] as $id => $values ){
                    if ( $values[ 'right' ] == 1 ){
                         $massive[ $numb ][ 'answ' ][] = $values[ 'name' ];
                         unset( $random_questions[ $numb ][ 'answ' ][ $id ] );
                    }
               }
               if ( count( $massive[ $numb ][ 'answ'] ) > 1 ){
                    $massive[ $numb ][ 'field' ] = "checkbox";
               }else{
                    $massive[ $numb ][ 'field' ] = "radio";
               }
               $random_answers =  array_rand($random_questions[$numb]['answ'], 3);
               foreach ( $random_answers as $id ){
                    $massive[ $numb ][ 'answ' ][] = $random_questions[$numb]['answ'][ $id ][ 'name' ];
               }
               shuffle( $massive[ $numb ][ 'answ' ] );
          }
          return $massive;
     }
     function SaveResults( $data ){
          $count_right = 0;
          foreach ( $data as $id => $value ){
               $sql = 'select id from questions where name = "' . $value[ 'name' ] . '"';
               $id = $this->database->SQL( $sql );
               $sql_1 = "select right_answer from answers where id_question = ". $id[0]['id']  ." and right_answer=true";
               $all_right = $this->database->SQL( $sql_1 );
               $count_all = count( $all_right );
               $time_right = 0;
               if ( count( $value[ 'answer' ] ) == 1 ){
                    $sql = 'select right_answer from answers where id_name = "' . $value[ 'answer' ][0] . '" and id_question = ' . $id[0]['id']  . '';
                    $right = $this->database->SQL( $sql );
                    if ( $right[0]['right_answer'] == true && count( $right) == $count_all ){
                         $count_right++;
                    }
               }else{
                    $implode_data = implode("\",\"", $value[ 'answer'] );
                    $sql = 'select right_answer from answers where id_name in ("' . $implode_data. '") and id_question = ' . $id[0]['id']  . '';
                    $right = $this->database->SQL( $sql );
                    foreach( $right as $right_value ){
                         if ( count( $right ) == $count_all ){
                              if ( $right_value[ 'right_answer' ] == true ){
                                   $time_right++;
                              }else{
                                   $time_right = 0;
                              }
                         }
                    }
                    if ( $time_right == $count_all ){
                         $count_right++;
                    }
               } 
          }
          session_start();
          $name_user = $_SESSION['name_auth'];
          session_destroy();
          $sql = 'select id from users where name = "' . $name_user . '"';
          $user_id = $this->database->SQL( $sql );
          //Добавляем результаты в таблицу
          $massive[] = $user_id[0]['id'];
          $massive[] = $count_right;
          $sql = 'insert into results (id_user, correct_answers) values (?, ?)';
          $insertResult = $this->database->SQL( $sql, $massive );
     }
     public function GetView(){
          $data = $this->GetData();
          var_dump( $data );
     }
}

?>