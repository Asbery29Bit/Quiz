<?php
defined('INDEX') OR die('Прямой доступ к странице запрещён!');
class Database{
     private $data = [
          'dbname'  => 'quiz',
          'host'    => 'localhost',
          'login'   => 'root',
          'pass'    => ''
     ];
     protected $DBH;
     function __construct(){
          try{
               $this->DBH = new PDO( 'mysql:host=' . $this->data[ 'host' ] . ';dbname=' . $this->data[ 'dbname' ] , $this->data[ 'login' ], $this->data[ 'pass' ] );
          }
          catch(PDOException $e) {
               echo "Хьюстон, у нас проблемы.\n";
               print_r( $e->getMessage() );
          }
     }
     public function SQL( $sql , $values = [] )
     {
          $solution = $this->DBH->prepare($sql);
          $solution->execute( $values );
          $results = $solution->fetchAll(PDO::FETCH_ASSOC);
          if ( empty( $results ) ){
               return [];
          }
          return $results;
     }
     
     public function perform( $sql, $values =[] )
     {
          $result = $this->DBH->prepare($sql);
          $result->execute();
     }

}

?>