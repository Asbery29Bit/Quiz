<?php
defined('INDEX') OR die('Прямой доступ к странице запрещён!');
include_once "Database.php";
class User{
     private $database;
     function __construct(){
          $this->database = new Database;
     }
     function checkUser ( $massive ){
          $sql = "select * from users where name = ?";
          foreach ( $massive as $key => $value ){
               $data[] = $value;
          }
          $result = $this->database->SQL( $sql, $data );
          return $result;
     }
     function createUser ( $massive ){
          $sql = "insert into users (name, date_start) values (?, ?)";
          foreach ( $massive as $key => $value ){
               $data[] = $value;
          }
          $result = $this->database->SQL( $sql, $data );
          return $result;
     }
     function updateUser( $name, $massive ){
          //Тут Ошибка с значениями.
          $sql = "update users set ";
          foreach ( $massive as $key => $value ){
               $sql .= $key . " = ?,";
               $data[] = $value;
          }
          $sql .= " where name = ?";
          $result = $this->database->SQL( $sql, $data );
          return $result;
     }
}

?>