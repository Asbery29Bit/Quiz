<?php
defined('INDEX') OR die('Прямой доступ к странице запрещён!');
class Router {
private $routes;
public function __construct()
{
    $routesPath = ROOT . '/templates/Config.php';
    $this->routes = include($routesPath);
}

public function run()
{
    $flag = false;
    if (!empty($_SERVER['REQUEST_URI'])) {
        $uri = trim($_SERVER['REQUEST_URI'], '/');
        foreach ( $this->routes as $key => $path ){
            if( $key == $uri ){
                if (file_exists(ROOT . $path)) {
                    include_once ROOT . "/templates/header.php";
                    include_once( ROOT . $path );
                    include_once ROOT . "/templates/footer.php";
                    $flag = true;
                }
            }
        } 

    }
    if ( $flag === false ){
        include_once( ROOT . '/404.php' );   
    }
}


}
?>