$( document ).ready(function() {
     url = "/ajax/ajaxGetQuestions.php";
     console.log ( 'sdfsd' );
     let massive = ajaxGetQuestions( url );
     function ajaxGetQuestions( url ) {
          $.ajax({
               url: url,
               method: "POST",
               data: '{}',
               contentType: "application/json; charset=utf-8",
               dataType: "json",
             }).done(function(response){
               var k = 0;
               $("#quest_name").append( response[k].name );
               if ( response[k].field == "radio" ){
                    for( value in response[k].answ ){
                         $("#quest_list").append( "<input type=\"radio\" id=\"quest\" name=\"radio\" value=\""+response[k].answ[value]+"\"><label for=\"quest\">"+response[k].answ[value]+"</label><br>" )
                    }
               }else if( response[k].field == "checkbox"  ){
                    for( value in response[k].answ ){
                         $("#quest_list").append( "<input type=\"checkbox\" id=\"quest\" name=\"checkbox\" value=\""+response[k].answ[value]+"\"><label for=\"quest\">"+response[k].answ[value]+"</label><br>" )
                    }
               }
               var size = Object.keys(response).length;
               let data = {};
               $("#buton_quest").click(function(){
                    val = [];
                    let params = {
                         name: response[k].name,
                         answer: ''
                    }
                    if ($('input[name="radio"]').is(':checked')){
                         val[0] = $('input[name="radio"]:checked').val();
                         params.answer = val;
                    }
                    $(':checkbox:checked').each(function(i){
                         val[i] = $(this).val();
                         params.answer = val;
                    });
                    data[ k ] = params;
                    k++;
                    $("#quest_name").html( response[k].name );
                    $("#quest_list").html("");
                    if ( response[k].field == "radio" ){
                         for( value in response[k].answ ){
                              $("#quest_list").append( "<input type=\"radio\" id=\"quest\" name=\"radio\" value=\""+response[k].answ[value]+"\"><label for=\"quest\">"+response[k].answ[value]+"</label><br>" )
                         }
                    }else if( response[k].field == "checkbox"  ){
                         for( value in response[k].answ ){
                              $("#quest_list").append( "<input type=\"checkbox\" id=\"quest\" name=\"checkbox\" value=\""+response[k].answ[value]+"\"><label for=\"quest\">"+response[k].answ[value]+"</label><br>" )
                         }
                    }
                    if ( k == size-1 ){
                         $("#button_send").html( '' );
                         $("#button_send").html( '<button id="buton_end_quest" class="next_quest"> Завершить тест</button>' );
                    }
                    $("#buton_end_quest").click(function(){
                         val = [];
                         let params = {
                              name: response[k].name,
                              answer: ''
                         }
                         if ($('input[name="radio"]').is(':checked')){
                              val[0] = $('input[name="radio"]:checked').val();
                              params.answer = val;
                         }
                         $(':checkbox:checked').each(function(i){
                              val[i] = $(this).val();
                              params.answer = val;
                         });
                         data[ k ] = params;
                         url = "/ajax/ajaxSendQuestions.php";
                         $.ajax({
                              url: url,
                              method: "POST",
                              data: {data: data},
                              dataType: "json",
                            });
                         setTimeout(function() { window.location = "/graph"; }, 1000); 
                    });
               });
             });
     }
 });               
