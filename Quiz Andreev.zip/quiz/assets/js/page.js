$( document ).ready(function() {
     $("#button_main").click(function(){
          name_user = $( "#name_user" ).val();
          if ( name_user ){
               url = "/ajax/ajaxPageinfo.php";
               let params = {
                    name: name_user
               }
               ajaxPageinfo( url, params )
          }else{
               alert( 'no text' );
          }
      });
      $("#back_button").click(function(){
               window.location = "/"; 
      });
     function ajaxPageinfo( url, params ) {
          let json = JSON.stringify(params);
          $.ajax({
               url: url,
               method: "POST",
               data: {data: json},
               dataType: "json"
             }).done(function(response){
               console.log( response );
               if( response.value == 'complete' ){
                    window.location = "/question"; 
               }else{
                    alert( "Username is zanato, napishi drugoe" );
               }
             });
     }
 });