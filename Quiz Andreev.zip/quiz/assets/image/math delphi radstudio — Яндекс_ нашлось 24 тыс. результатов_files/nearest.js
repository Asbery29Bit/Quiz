var YaStaticRegion = "mskm"
