<?php
define("INDEX", "");
define("ROOT", __DIR__);
include_once( "init.php" );
?>